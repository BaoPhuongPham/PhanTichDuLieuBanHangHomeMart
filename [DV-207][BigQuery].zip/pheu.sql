-- Biểu đồ phễu với các giai đoạn: Cầm sản phẩm, Đặt vào giỏ, Mua sản phẩm
SELECT 'Cầm sản phẩm' AS Stage, SUM(
  CASE
    WHEN PickingUpItem THEN 1
    ELSE 0
  END
) AS Value
FROM `HomeMart.Customer`

UNION ALL

SELECT 'Đặt vào giỏ' AS Stage, SUM(
  CASE
    WHEN PuttingItemIntoBag OR DaMua THEN 1
    ELSE 0
  END
) AS Value
FROM `HomeMart.Customer`

UNION ALL

SELECT 'Mua sản phẩm' AS Stage, SUM(
  CASE
    WHEN PuttingItemIntoBag AND DaMua THEN 1
    ELSE 0
  END
) AS Value
FROM `HomeMart.Customer`
