SELECT
    -- Chuyển timestamp bị sai thành đúng bằng cách đảo lại
    PARSE_TIMESTAMP('%m/%d/%Y %H:%M:%S', FORMAT_TIMESTAMP('%d/%m/%Y %H:%M:%S', c.TimeStamp)) AS TimeStamp,

    c.PersonID,
    c.DaMua,
    CAST(c.PersonID AS STRING) || '_' || FORMAT_TIMESTAMP('%d/%m/%Y %H:%M:%S', c.TimeStamp) AS TransactionID,

    CASE 
        WHEN c.DaMua = TRUE THEN i.Price * (1 - i.`Discount ` / 100.0)
        ELSE 0
    END AS TongChiTieu,

    s.Description,
    i.Name

FROM
    `HomeMart.Customer` c
JOIN
    `HomeMart.Item` i ON c.Key = i.Key
JOIN
    `HomeMart.Shelf` s ON i.ShelfID = s.ShelfID
