SELECT
  PersonID,
  SUM(TongChiTieu) AS TongChiTieuTheoKhach
FROM
  `HomeMart.KH_ChiTieu`
GROUP BY
  PersonID
ORDER BY
  TongChiTieuTheoKhach DESC
