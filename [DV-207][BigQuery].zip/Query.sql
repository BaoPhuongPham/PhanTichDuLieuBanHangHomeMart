SELECT
  PersonID,
  AVG(MovingSpeed) AS AvgMovingSpeed,
  SUM(CASE WHEN TakingItemOutOfBag THEN 1 ELSE 0 END) AS TotalTakeOutBag,
  SUM(CASE WHEN ReturningItem THEN 1 ELSE 0 END) AS TotalReturns,
  SUM(CASE WHEN PuttingItemIntoBag THEN 1 ELSE 0 END) AS TotalPutInBag,
  SUM(CASE WHEN PickingUpItem THEN 1 ELSE 0 END) AS TotalPickUps,
  SUM(LookingAtItem) AS TotalLookingTime,
  SUM(CASE WHEN DaMua THEN 1 ELSE 0 END) AS TotalItemsBought,
  SUM(HoldingTheItem) AS TotalHoldingTime,

  -- Tính điểm tương tác
  SUM(LookingAtItem) + 
  SUM(HoldingTheItem) + 
  SUM(CASE WHEN PickingUpItem THEN 1 ELSE 0 END) + 
  SUM(CASE WHEN PuttingItemIntoBag THEN 1 ELSE 0 END) AS InteractionScore,

  -- Phân nhóm khách hàng
  CASE
    WHEN AVG(MovingSpeed) >= 0.80 
         AND (SUM(LookingAtItem) + SUM(HoldingTheItem) + 
              SUM(CASE WHEN PickingUpItem THEN 1 ELSE 0 END) + 
              SUM(CASE WHEN PuttingItemIntoBag THEN 1 ELSE 0 END)) <= 600 
         AND SUM(CASE WHEN DaMua THEN 1 ELSE 0 END) >= 10
      THEN 'Di chuyển nhanh, ít tương tác, mua hiệu quả'

    WHEN (SUM(LookingAtItem) + SUM(HoldingTheItem) + 
          SUM(CASE WHEN PickingUpItem THEN 1 ELSE 0 END) + 
          SUM(CASE WHEN PuttingItemIntoBag THEN 1 ELSE 0 END)) >= 650 
         AND SUM(CASE WHEN DaMua THEN 1 ELSE 0 END) < 10
      THEN 'Tương tác nhiều nhưng ít mua'

    WHEN SUM(CASE WHEN ReturningItem THEN 1 ELSE 0 END) > 0 
         OR SUM(CASE WHEN TakingItemOutOfBag THEN 1 ELSE 0 END) > 0
      THEN 'Có xu hướng trả lại hoặc lấy ra khỏi giỏ'

    ELSE 'Other'
  END AS CustomerSegment

FROM `HomeMart.Customer`
GROUP BY PersonID
