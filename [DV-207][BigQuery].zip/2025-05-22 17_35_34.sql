SELECT
  sh.Description AS Shelf_Description,
  it.Name AS Item_Name,
  it.Rate AS Item_Rate,
  SUM(IF(cu.DaMua, 1, 0)) AS TongSoLuongMua
FROM
  `HomeMart.Shelf` sh
JOIN
  `HomeMart.Item` it ON sh.ShelfID = it.ShelfID
JOIN
  `HomeMart.Customer` cu ON it.key = cu.key
GROUP BY
  sh.Description, it.Name, it.Rate
