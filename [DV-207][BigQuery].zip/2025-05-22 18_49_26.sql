SELECT 
  it.Origin AS Country,
  sh.Description AS Shelf,
  AVG(it.Price) AS AvgPrice
FROM 
  `HomeMart.Item` it
JOIN 
  `HomeMart.Shelf` sh ON it.ShelfID = sh.ShelfID
GROUP BY 
  it.Origin, sh.Description
