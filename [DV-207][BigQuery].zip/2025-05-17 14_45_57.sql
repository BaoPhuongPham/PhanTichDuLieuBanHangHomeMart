CREATE OR REPLACE TABLE `HomeMart.PhanKhucKH` AS
SELECT 'Mua nhiều - Tương tác cao' AS nhom_khach_hang, 338 AS so_luong
UNION ALL
SELECT 'Mua trung bình - Tương tác vừa', 561
UNION ALL
SELECT 'Ít mua, ít tương tác', 601;
