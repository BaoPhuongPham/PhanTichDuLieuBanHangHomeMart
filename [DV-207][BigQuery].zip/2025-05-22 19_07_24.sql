SELECT
  it.Name AS Item_Name,
  it.HSD,
  CASE 
    WHEN DATE('2024-07-01') > DATE(it.HSD) THEN DATE_DIFF(DATE('2024-07-01'), DATE(it.HSD), DAY)
    ELSE 0
  END AS SoNgayHetHan
FROM
  `HomeMart.Item` it
