SELECT
  it.Name AS Item_Name,
  SUM(tt.TongThoiGianTuongTac) AS TongThoiGianTuongTac
FROM
  `HomeMart.Item` it
JOIN
  `HomeMart.TuongTac` tt
  ON it.key = tt.key
GROUP BY
  it.Name
