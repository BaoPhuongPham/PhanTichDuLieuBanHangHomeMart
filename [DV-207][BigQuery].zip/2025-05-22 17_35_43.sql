WITH interaction AS (
  SELECT
    c.`Key`,
    i.`Discount `,
    
    -- Xác định mức giảm giá
    CASE
      WHEN i.`Discount ` = 0 THEN 'Không giảm giá'
      WHEN i.`Discount ` BETWEEN 1 AND 9 THEN '<10%'
      WHEN i.`Discount ` BETWEEN 10 AND 20 THEN '10-20%'
      WHEN i.`Discount ` > 20 THEN '>20%'
      ELSE 'Không xác định'
    END AS Discount_Level,
    
    -- Chuyển đổi hành vi
    IF(c.`LookingAtItem` > 0, 1, 0) AS View,
    IF(c.`PickingUpItem` = TRUE, 1, 0) AS Touch,
    IF(c.`PuttingItemIntoBag` = TRUE, 1, 0) AS Add_to_cart,
    IF(c.`DaMua` = TRUE, 1, 0) AS Purchase,
    
    c.`PersonID`
    
  FROM
    `HomeMart.Customer` c
  JOIN
    `HomeMart.Item` i
  ON
    c.`Key` = i.`Key`
)

SELECT
  Discount_Level AS `Mức giảm giá`,
  SUM(View) AS `Xem`,
  COUNTIF(Touch = 1) AS `Cầm sản phẩm`,
  COUNTIF(Add_to_cart = 1) AS `Bỏ vào giỏ`,
  COUNTIF(Purchase = 1) AS `Mua`
FROM
  interaction
GROUP BY
  Discount_Level
ORDER BY
  CASE Discount_Level
    WHEN 'Không giảm giá' THEN 0
    WHEN '<10%' THEN 1
    WHEN '10-20%' THEN 2
    WHEN '>20%' THEN 3
    ELSE 4
  END;
