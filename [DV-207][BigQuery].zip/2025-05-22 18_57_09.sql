SELECT
  it.Name AS Item_Name,
  AVG(cu.LookingAtItem) AS Avg_LookingAtItem
FROM
  `HomeMart.Item` it
JOIN
  `HomeMart.Customer` cu
  ON it.key = cu.key
GROUP BY
  it.Name
