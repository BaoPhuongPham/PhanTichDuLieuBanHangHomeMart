SELECT
    -- Chuyển timestamp bị sai thành đúng bằng cách đảo lại
    PARSE_TIMESTAMP('%m/%d/%Y %H:%M:%S', FORMAT_TIMESTAMP('%d/%m/%Y %H:%M:%S', c.TimeStamp)) AS TimeStamp,

    c.PersonID,
    c.DaMua,

    -- Transaction ID
    CAST(c.PersonID AS STRING) || '_' || FORMAT_TIMESTAMP('%d/%m/%Y %H:%M:%S', c.TimeStamp) AS TransactionID,

    -- Tổng chi tiêu nếu đã mua
    CASE 
        WHEN c.DaMua = TRUE THEN i.Price * (1 - i.`Discount ` / 100.0)
        ELSE 0
    END AS TongChiTieu,

    -- Trường bổ sung từ bảng Customer
    c.Gender,
    c.MarriedStatus,

    -- Phân nhóm tuổi
    CASE
        WHEN c.Age BETWEEN 18 AND 30 THEN 'Thiếu niên'
        WHEN c.Age BETWEEN 31 AND 60 THEN 'Trung niên'
        WHEN c.Age > 60 THEN 'Cao tuổi'
        ELSE 'Không xác định'
    END AS NhomTuoi,

    -- Thông tin mặt hàng và quầy
    s.Description,
    i.Name

FROM
    `HomeMart.Customer` c
JOIN
    `HomeMart.Item` i ON c.Key = i.Key
JOIN
    `HomeMart.Shelf` s ON i.ShelfID = s.ShelfID
