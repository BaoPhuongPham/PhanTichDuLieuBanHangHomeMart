SELECT
  sh.Description AS Shelf_Description,
  it.Name AS Item_Name,
  SUM(IF(cu.`ReturningItem` = TRUE, 1, 0)) AS SoLanTraLai
FROM
  `HomeMart.Shelf` sh
JOIN
  `HomeMart.Item` it ON sh.ShelfID = it.ShelfID
JOIN
  `HomeMart.Customer` cu ON it.key = cu.key
GROUP BY
  sh.Description,
  it.Name
